#!/usr/bin/env python3
"""Compare the vault's health to a saved baseline.

Existing issues are recorded in .github/vault-check-baseline.json. The check
fails only when a new issue appears, so the vault can improve over time without
having to be perfect first. See 00-System/Vault-Check.md.

Usage:
    python3 .github/scripts/vault_check.py
    python3 .github/scripts/vault_check.py --update-baseline

Standard library only. Python 3.8 or later.
"""
import argparse
import json
import os
import re
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path

METADATA_NOTE = "00-System/Metadata-Standards.md"
LIFECYCLE_NOTE = "00-System/Lifecycle-States.md"
BASELINE_PATH = ".github/vault-check-baseline.json"

# Folders that stay out of Git, so a run on GitHub can't see them.
IGNORED_FOLDERS = ("90-Local/", "90-Local-Admin/", "99-Archived/", "Templates/")
# Dated records and working files that don't need the full metadata set.
NO_METADATA_CHECK = ("11-Research/",) + IGNORED_FOLDERS
# Dated records keep their links as written, so dead links there are warnings.
LINKS_WARN_ONLY = ("11-Research/",)
SHARED_NAMES = {"readme", "index"}
SKIP_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".pdf", ".canvas", ".mp3", ".mp4")
CANONICAL_MAX_AGE_DAYS = 180

LABELS = {
    "unresolved": "Link to a note that doesn't exist",
    "archive-link": "Link into 99-Archived",
    "metadata": "Missing required metadata",
    "artifact-type": "Artifact type not in Metadata-Standards",
    "status": "Status not in Lifecycle-States",
    "duplicate": "Two notes share a name",
    "conflict-copy": "Likely sync or conflict copy of another note",
    "empty": "Empty note",
    "publish": "publish: true without client_safe: true and publish-ready",
}
LINK_RE = re.compile(r"\[\[([^\]|#^\\]+)(?:[#^][^\]|]*)?(?:\\?\|[^\]]*)?\]\]")
INLINE_CODE_RE = re.compile(r"`[^`\n]*`")
FENCE_RE = re.compile(r"^\s*(`{3,}|~{3,})")
COPY_SUFFIX_RE = re.compile(r"(?:-\d+| \d+| \(\d+\)| copy| conflicted copy.*)$", re.I)


def list_notes(root):
    """Return vault-relative paths of Markdown notes, using what Git would commit."""
    try:
        output = subprocess.run(
            ["git", "-C", str(root), "ls-files", "-z", "--cached", "--others", "--exclude-standard", "--", "*.md"],
            check=True,
            capture_output=True,
        ).stdout
        paths = [p for p in output.decode("utf-8").split("\0") if p]
    except (OSError, subprocess.CalledProcessError):
        paths = [p.relative_to(root).as_posix() for p in root.rglob("*.md")]
        paths = [p for p in paths if not p.startswith(IGNORED_FOLDERS)]
    return sorted(p for p in paths if not p.startswith(".") and (root / p).is_file())


def read_note(path):
    return path.read_text(encoding="utf-8-sig", errors="replace").replace("\r\n", "\n")


def split_frontmatter(text):
    """Return (frontmatter fields, body). Only top-level keys are read."""
    match = re.match(r"---\n(.*?)\n?---[ \t]*(?:\n|$)", text, re.S)
    if not match:
        return {}, text
    fields = {}
    for line in match.group(1).split("\n"):
        field = re.match(r"([A-Za-z_][\w-]*):[ \t]*(.*)$", line)
        if field:
            value = re.sub(r"\s+#.*$", "", field.group(2)).strip().strip("\"'")
            fields[field.group(1)] = value
    return fields, text[match.end():]


def strip_code(body):
    """Remove fenced and inline code so examples don't count as links."""
    kept, fence = [], None
    for line in body.split("\n"):
        marker = FENCE_RE.match(line)
        if fence:
            if marker and marker.group(1)[0] == fence[0] and len(marker.group(1)) >= len(fence):
                fence = None
            continue
        if marker:
            fence = marker.group(1)
            continue
        kept.append(INLINE_CODE_RE.sub("", line))
    return "\n".join(kept)


def table_values(text, heading):
    """Return the first column of the table under a heading in a governance note."""
    values, in_section = [], False
    for line in text.split("\n"):
        if line.startswith("#"):
            in_section = line.lstrip("# ").strip() == heading
        elif in_section and line.startswith("|"):
            cell = line.split("|")[1].strip()
            if cell and cell not in {"Type", "State"} and not set(cell) <= set("-: "):
                values.append(cell)
    return set(values)


def required_fields(text):
    """Return the keys in the YAML block under Minimum Required Metadata."""
    match = re.search(r"# Minimum Required Metadata.*?```yaml\n(.*?)```", text, re.S)
    return re.findall(r"^([a-z_]+):", match.group(1), re.M) if match else []


def link_index(notes):
    """Map every path suffix of every note, as Obsidian matches links."""
    index = set()
    for note in notes:
        parts = note[:-3].lower().split("/")
        index.update("/".join(parts[i:]) for i in range(len(parts)))
    return index


def normalize_target(target):
    value = target.strip().lower()
    value = re.sub(r"^(\.{0,2}/)+", "", value)
    return value[:-3] if value.endswith(".md") else value


def find_issues(root, notes):
    """Return (error keys, warning keys). Keys are stable across runs."""
    metadata_text = read_note(root / METADATA_NOTE)
    lifecycle_text = read_note(root / LIFECYCLE_NOTE)
    required = required_fields(metadata_text)
    types = table_values(metadata_text, "Approved Artifact Types")
    states = table_values(lifecycle_text, "Lifecycle Model")
    if not (required and types and states):
        sys.exit("Could not read the rules from Metadata-Standards or Lifecycle-States. Check their headings.")

    known = link_index(notes)
    errors, warnings = set(), set()

    names = defaultdict(list)
    for note in notes:
        names[Path(note).stem.lower()].append(note)
    for name, paths in names.items():
        if len(paths) > 1 and name not in SHARED_NAMES:
            errors.add(f"duplicate|{name}")
    for note in notes:
        original = COPY_SUFFIX_RE.sub("", Path(note).stem)
        if original != Path(note).stem and original.lower() in names:
            errors.add(f"conflict-copy|{note}")

    today = date.today()
    for note in notes:
        fields, body = split_frontmatter(read_note(root / note))

        if not body.strip():
            errors.add(f"empty|{note}")

        for target in LINK_RE.findall(strip_code(body)):
            clean = normalize_target(target)
            if not clean or "{{" in clean or "<%" in clean or clean.endswith(SKIP_EXTENSIONS):
                continue
            if clean.startswith("99-archived/"):
                errors.add(f"archive-link|{note}|{clean}")
            elif clean not in known:
                bucket = warnings if note.startswith(LINKS_WARN_ONLY) else errors
                bucket.add(f"unresolved|{note}|{clean}")

        if not note.startswith(NO_METADATA_CHECK):
            for field in required:
                if not fields.get(field):
                    errors.add(f"metadata|{note}|{field}")
            kind = fields.get("artifact_type")
            if kind and kind not in types:
                errors.add(f"artifact-type|{note}|{kind}")
            status = fields.get("status")
            if status and status not in states:
                errors.add(f"status|{note}|{status}")

        if fields.get("publish", "").lower() == "true":
            if fields.get("client_safe", "").lower() != "true" or fields.get("status") != "publish-ready":
                errors.add(f"publish|{note}")

        if fields.get("status") == "canonical":
            try:
                updated = datetime.strptime(fields.get("last_updated", "")[:10], "%Y-%m-%d").date()
            except ValueError:
                updated = None
            if updated and (today - updated).days > CANONICAL_MAX_AGE_DAYS:
                warnings.add(f"canonical-age|{note}|{updated.isoformat()}")

    return errors, warnings


def describe(key):
    kind, *detail = key.split("|")
    return f"{kind}: " + " -> ".join(detail)


def count_lines(keys):
    counts = Counter(key.split("|")[0] for key in keys)
    return [f"- {LABELS.get(kind, kind)}: {counts[kind]}" for kind in sorted(counts)]


def report(new, fixed, known, warnings, note_count):
    lines = [
        "## Vault check",
        "",
        f"{note_count} notes checked. {len(new)} new, {len(fixed)} fixed, {len(known)} known, {len(warnings)} warnings.",
        "",
    ]
    if new:
        lines += ["### New issues", ""] + [f"- `{describe(k)}`" for k in sorted(new)] + [""]
    if fixed:
        lines += ["### Fixed since the baseline", ""] + [f"- `{describe(k)}`" for k in sorted(fixed)[:25]]
        if len(fixed) > 25:
            lines.append(f"- and {len(fixed) - 25} more")
        lines += ["", "Run the workflow with `update_baseline` to lock these in.", ""]
    if known:
        lines += ["### Known issues", ""] + count_lines(known) + [""]
    if warnings:
        lines += ["### Warnings", ""] + count_lines(warnings) + [""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[2]), help="vault folder")
    parser.add_argument("--update-baseline", action="store_true", help="accept current issues")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    baseline_file = root / BASELINE_PATH
    notes = list_notes(root)
    errors, warnings = find_issues(root, notes)

    if args.update_baseline:
        payload = {
            "note": "Known issues. The check fails only on issues not listed here.",
            "issues": sorted(errors),
        }
        baseline_file.write_text(json.dumps(payload, indent=1) + "\n", encoding="utf-8")
        print(f"Baseline updated with {len(errors)} known issues.")
        return 0

    baseline = set()
    if baseline_file.exists():
        baseline = set(json.loads(baseline_file.read_text(encoding="utf-8"))["issues"])

    new, fixed, known = errors - baseline, baseline - errors, errors & baseline
    summary = report(new, fixed, known, warnings, len(notes))
    print(summary)
    summary_file = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary_file:
        with open(summary_file, "a", encoding="utf-8") as handle:
            handle.write(summary + "\n")
    return 1 if new else 0


if __name__ == "__main__":
    sys.exit(main())
